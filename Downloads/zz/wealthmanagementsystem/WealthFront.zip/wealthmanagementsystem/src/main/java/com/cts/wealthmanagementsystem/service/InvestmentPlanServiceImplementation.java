package com.cts.wealthmanagementsystem.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.wealthmanagementsystem.entity.InvestmentPlan;
import com.cts.wealthmanagementsystem.repository.InvestmentRepository;

@Service
public class InvestmentPlanServiceImplementation implements InvestmentPlanService {
	@Autowired
	private InvestmentRepository  investmentRepository  ;

	@Override
	public InvestmentPlan addInvestmentPlan(InvestmentPlan investmentPlan) {
		return investmentRepository.save(investmentPlan);
	}
	

	
}
