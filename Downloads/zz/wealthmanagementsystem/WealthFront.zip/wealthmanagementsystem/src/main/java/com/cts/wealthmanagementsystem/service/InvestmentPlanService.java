package com.cts.wealthmanagementsystem.service;


import com.cts.wealthmanagementsystem.entity.InvestmentPlan;

public interface InvestmentPlanService {
	
	public InvestmentPlan addInvestmentPlan(InvestmentPlan investmentPlan);

}
