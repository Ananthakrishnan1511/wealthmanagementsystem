package com.cts.wealthmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WealthmanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
