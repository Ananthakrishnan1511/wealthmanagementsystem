package com.cts.wealthmanagementsystem.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.wealthmanagementsystem.entity.InvestmentPlan;
import com.cts.wealthmanagementsystem.repository.InvestmentRepository;

public interface PortfolioServiceImplementation  {
	
}
