package com.cts.wealthmanagementsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cts.wealthmanagementsystem.entity.InvestmentPlan;
import com.cts.wealthmanagementsystem.entity.PortfolioItem;
import com.cts.wealthmanagementsystem.repository.InvestmentRepository;
import com.cts.wealthmanagementsystem.repository.PortfolioRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;
import java.util.stream.Collectors;

/**
 * Service class responsible for portfolio calculations and generating rebalancing ideas.
 */
@Service

public class PortfolioService {
	  @Autowired
		private PortfolioRepository portfolioRepository ;
	  
	 
		public PortfolioItem addPortfolioItem(PortfolioItem portfolioItem) {
			System.out.print(portfolioItem.getProfitLoss());
			return portfolioRepository.save(portfolioItem);
		}
     

    // Simulate current market values for demonstration purposes.
    // In a real-world application, these values would be fetched from
    // external financial APIs or a database.
    private static final double GOLD_CURRENT_VALUE_FACTOR = 1.10; // 10% increase from buy value
    private static final double MUTUAL_FUNDS_CURRENT_VALUE_FACTOR = 0.95; // 5% decrease from buy value
    private static final double SHARE_MARKET_CURRENT_VALUE_FACTOR = 1.25; // 25% increase from buy value

    // --- Rebalancing Strategy Parameters (can be made configurable) ---
    private static final double TARGET_MIN_ALLOCATION_PERCENT = 20.0; // Aim for at least 20% for performing assets
    private static final double OVER_ALLOCATION_THRESHOLD_PERCENT = 40.0; // If allocation is above this, suggest trimming
    private static final double UNDER_ALLOCATION_THRESHOLD_PERCENT = 15.0; // If allocation is below this, suggest increasing
    private static final double PROFIT_TAKING_PERCENT = 0.10; // Suggest taking 10% of profit if over-allocated
    private static final double LOSS_COVERAGE_PERCENT = 0.50; // Suggest covering 50% of the loss

    /**
     * Calculates and returns a list of PortfolioItem objects based on provided buy values.
     * It simulates current values and then calculates profit/loss and allocation percentages.
     *
     * @param goldBuyValue The initial investment value for Gold.
     * @param mutualFundsBuyValue The initial investment value for Mutual Funds.
     * @param shareMarketBuyValue The initial investment value for Share Market.
     * @return A list of PortfolioItem objects with calculated current values, profit/loss, and allocations.
     */
    public List<PortfolioItem> getPortfolio(double goldBuyValue, double mutualFundsBuyValue, double shareMarketBuyValue,@ModelAttribute("portfolioItems") List<PortfolioItem> portfolioItems) {
       

        // Simulate current values based on predefined factors
        // For a real application, these would come from an external API or database
        double goldCurrentValue = goldBuyValue * GOLD_CURRENT_VALUE_FACTOR;
        double mutualFundsCurrentValue = mutualFundsBuyValue * MUTUAL_FUNDS_CURRENT_VALUE_FACTOR;
        double shareMarketCurrentValue = shareMarketBuyValue * SHARE_MARKET_CURRENT_VALUE_FACTOR;

        // Create portfolio items with their simulated current values
        portfolioItems.add(new PortfolioItem("Gold", goldBuyValue, goldCurrentValue, 0.0, 0.0));
        portfolioItems.add(new PortfolioItem("Mutual Funds", mutualFundsBuyValue, mutualFundsCurrentValue, 0.0, 0.0));
        portfolioItems.add(new PortfolioItem("Share Market", shareMarketBuyValue, shareMarketCurrentValue, 0.0, 0.0));

        // Calculate profit/loss and allocation percentages for all items
        calculateProfitLossAndAllocation(portfolioItems);
        return portfolioItems;
    }

  


    /**
     * Helper method to calculate profit/loss and allocation percentages for a given list of portfolio items.
     *
     * @param portfolioItems The list of PortfolioItem objects to process.
     */
    private void calculateProfitLossAndAllocation(@ModelAttribute("portfolioItems") List<PortfolioItem> portfolioItems) {
        // Calculate the total current market value of the entire portfolio
        double totalCurrentValue = portfolioItems.stream()
                .mapToDouble(PortfolioItem::getCurrentValue)
                .sum();

        // Iterate through each item to calculate its profit/loss and allocation
        for (PortfolioItem item : portfolioItems) {
            double profitLoss = item.getCurrentValue() - item.getBuyValue();
            item.setProfitLoss(profitLoss);

            // Calculate allocation percentage only if total current value is positive to avoid division by zero
            if (totalCurrentValue > 0) {
                double allocationPercentage = (item.getCurrentValue() / totalCurrentValue) * 100;
                item.setAllocationPercentage(allocationPercentage);
            } else {
                item.setAllocationPercentage(0.0); // If total value is zero, allocation is zero
            }
            
            addPortfolioItem(item);
        }
        
    }

    /**
     * Generates attractive rebalancing ideas with suggested values based on the current state of the portfolio,
     * ensuring at least three ideas are always provided.
     *
     * @param portfolioItems The list of PortfolioItem objects representing the current portfolio.
     * @return A list of strings, each representing a rebalancing suggestion with values.
     */
    public List<String> getRebalancingIdeas(List<PortfolioItem> portfolioItems) {
        List<String> ideas = new ArrayList<>();
        double totalCurrentValue = portfolioItems.stream().mapToDouble(PortfolioItem::getCurrentValue).sum();

        // Separate items into gainers and losers
        List<PortfolioItem> losers = portfolioItems.stream()
                .filter(item -> item.getProfitLoss() < 0)
                .sorted(Comparator.comparingDouble(PortfolioItem::getProfitLoss)) // Sort by most significant loss first
                .collect(Collectors.toList());

        List<PortfolioItem> gainers = portfolioItems.stream()
                .filter(item -> item.getProfitLoss() >= 0)
                .sorted(Comparator.comparingDouble(PortfolioItem::getProfitLoss).reversed()) // Sort by most significant gain first
                .collect(Collectors.toList());

        // --- Idea 1: Address significant losses first ---
        for (PortfolioItem item : losers) {
            // Suggest an amount to cover a percentage of the loss
            double suggestedInvestment = Math.abs(item.getProfitLoss()) * LOSS_COVERAGE_PERCENT;
            if (suggestedInvestment > 0) { // Only suggest if there's an actual loss to cover
                ideas.add(String.format("Your **%s** investment is down. Consider **adding $%.2f** to average down your cost basis. This could help recover losses faster if the asset rebounds.",
                        item.getName(), suggestedInvestment));
                if (ideas.size() >= 3) break; // Limit initial specific ideas if enough generated
            }
        }

        // --- Idea 2: Rebalance from over-allocated gainers ---
        for (PortfolioItem item : gainers) {
            if (item.getAllocationPercentage() > OVER_ALLOCATION_THRESHOLD_PERCENT) {
                // Suggest taking a percentage of the profit or an amount to reduce allocation
                double amountToTrim = item.getProfitLoss() * PROFIT_TAKING_PERCENT;
                // Ensure we don't suggest trimming more than the current value or an unreasonable amount
                amountToTrim = Math.min(amountToTrim, item.getCurrentValue() * 0.20); // Cap at 20% of current value for trimming
                if (amountToTrim > 0) {
                    ideas.add(String.format("Your **%s** has performed exceptionally well (%.2f%% allocation). Consider **taking $%.2f in profits** to diversify and reduce concentration risk.",
                            item.getName(), item.getAllocationPercentage(), amountToTrim));
                    if (ideas.size() >= 3) break;
                }
            }
        }

        // --- Idea 3: Increase allocation for under-allocated but performing assets ---
        for (PortfolioItem item : gainers) {
            if (item.getAllocationPercentage() < UNDER_ALLOCATION_THRESHOLD_PERCENT && item.getProfitLoss() > 0) {
                // Suggest an amount to bring it closer to the target minimum allocation
                double targetValueForMinAllocation = totalCurrentValue * (TARGET_MIN_ALLOCATION_PERCENT / 100.0);
                double suggestedInvestment = targetValueForMinAllocation - item.getCurrentValue();
                if (suggestedInvestment > 0) {
                    ideas.add(String.format("Your **%s** is performing well but is under-allocated (%.2f%%). Consider **investing an additional $%.2f** to boost its contribution to your portfolio's growth.",
                            item.getName(), item.getAllocationPercentage(), suggestedInvestment));
                    if (ideas.size() >= 3) break;
                }
            }
        }

        // --- Ensure at least three ideas are generated, filling with general advice if needed ---
        while (ideas.size() < 3) {
            if (ideas.size() == 0 && !losers.isEmpty()) {
                // Fallback for a significant loss if previous specific suggestions didn't hit 3
                PortfolioItem mostLostItem = losers.get(0);
                double suggestedInvestment = Math.abs(mostLostItem.getProfitLoss()) * LOSS_COVERAGE_PERCENT * 0.75; // Slightly less than initial
                ideas.add(String.format("Your portfolio has some areas to optimize. For instance, **%s** is currently in loss. A strategic investment of **$%.2f** could help improve its performance.",
                        mostLostItem.getName(), suggestedInvestment));
            } else if (ideas.size() == 0 && !gainers.isEmpty()) {
                // Fallback for a good performing asset to increase allocation
                PortfolioItem bestPerformingItem = gainers.get(0);
                double suggestedInvestment = bestPerformingItem.getCurrentValue() * 0.05; // 5% of current value
                ideas.add(String.format("Your **%s** asset is showing strong performance. Consider **investing an additional $%.2f** to capitalize further on its growth potential.",
                        bestPerformingItem.getName(), suggestedInvestment));
            }
            else {
                // Add general rebalancing advice if specific scenarios don't fill up slots
                ideas.add("Regularly **review your asset allocation** to ensure it aligns with your financial goals and risk tolerance. Market fluctuations can shift your portfolio's balance over time.");
                ideas.add("Consider **diversifying your investments** across different asset classes (e.g., real estate, bonds) to spread risk and potentially improve returns, especially if your current portfolio is concentrated.");
                ideas.add("Don't forget to **reassess your risk profile** periodically. As your financial situation or goals change, your willingness or ability to take on risk might also change, necessitating portfolio adjustments.");
            }

            // Prevent infinite loop if no new unique ideas can be generated and size is still less than 3
            if (ideas.size() == 0 && portfolioItems.isEmpty()) {
                ideas.add("No portfolio data to analyze. Please add investment details to get personalized rebalancing ideas.");
                break;
            }
             // Add a general healthy portfolio message if all else fails and portfolio is generally balanced
            if (ideas.size() < 3 && portfolioItems.stream().allMatch(item -> item.getProfitLoss() >= 0 && item.getAllocationPercentage() >= UNDER_ALLOCATION_THRESHOLD_PERCENT && item.getAllocationPercentage() <= OVER_ALLOCATION_THRESHOLD_PERCENT)) {
                ideas.add("Your portfolio appears well-balanced and healthy. Continue monitoring market conditions regularly and review your investment goals periodically.");
            }
            if (ideas.size() < 3 && !portfolioItems.isEmpty()) {
                ideas.add("For a deeper dive, consider consulting a financial advisor to fine-tune your rebalancing strategy based on your unique financial situation and future aspirations.");
            }
        }
        return ideas.stream().distinct().limit(3).collect(Collectors.toList()); // Ensure uniqueness and limit to 3
    }
}