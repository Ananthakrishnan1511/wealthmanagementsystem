package com.cts.wealthmanagementsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.cts.wealthmanagementsystem.entity.ChoosenPlan;
import com.cts.wealthmanagementsystem.entity.PortfolioItem;
import com.cts.wealthmanagementsystem.service.PortfolioService;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects; // Make sure this is imported

/**
 * Controller for handling portfolio-related web requests.
 * Uses `@SessionAttributes` to store investment values passed from the planning module.
 */
@Controller
@SessionAttributes({"totalInvestment", "goldBuyValue", "mutualFundsBuyValue", "shareMarketBuyValue","portfolioItems"})
public class PortfolioController {

    @Autowired
    private PortfolioService portfolioService;

    /**
     * Handles the request for the main portfolio page.
     * It retrieves investment data from session attributes. If no data is in the session,
     * it assumes the planning module has not yet sent values, and redirects to a default state
     * or displays an empty portfolio with a message.
     *
     * @param model The Spring Model object to pass data to the view.
     * @return The name of the Thymeleaf template to render ("portfolio").
     */
    
    @ModelAttribute("portfolioItems")
    public List<PortfolioItem> portfolioItem() {
        return new ArrayList<>();
    }
    @GetMapping("/view") // This maps to /view
    public String home(Model model,@ModelAttribute("portfolioItems") List<PortfolioItem> portfolioItems) {
        System.out.println("PortfolioController.home() method called.");

        // Safely retrieve session attributes.
        // Use Objects.requireNonNullElse with a default, and cast to Number to handle both Integer and Double.
        double goldBuyValue = ((Number) Objects.requireNonNullElse(model.getAttribute("goldBuyValue"), 0.0)).doubleValue();
        // This was the line causing the NPE before: mutualFundsBuyValueObj was null, then .doubleValue() called.
        double mutualFundsBuyValue = ((Number) Objects.requireNonNullElse(model.getAttribute("mutualFundsBuyValue"), 0.0)).doubleValue();
        double shareMarketBuyValue = ((Number) Objects.requireNonNullElse(model.getAttribute("shareMarketBuyValue"), 0.0)).doubleValue();
        double totalInvestment = ((Number) Objects.requireNonNullElse(model.getAttribute("totalInvestment"), 0.0)).doubleValue();

        // If no values are present, it means the /displayPortfolioFromPlan endpoint hasn't been called.
        // In a real scenario, you might redirect to the planning module or show a message.
        if (totalInvestment == 0.0 && goldBuyValue == 0.0 && mutualFundsBuyValue == 0.0 && shareMarketBuyValue == 0.0) {
            System.out.println("No investment data found in session. Displaying empty portfolio.");
            model.addAttribute("message", "Please select an investment plan from the planning module to view your portfolio.");
        }
        model.addAttribute("portfolioItems",portfolioItems);
        // Get portfolio details and rebalancing ideas from the service using the current session values
        List<PortfolioItem> portfolioItems1 = portfolioService.getPortfolio(goldBuyValue, mutualFundsBuyValue, shareMarketBuyValue,portfolioItems);
        List<String> rebalancingIdeas = portfolioService.getRebalancingIdeas(portfolioItems1);

        // Add all necessary data to the model for Thymeleaf rendering
        model.addAttribute("portfolioItems", portfolioItems1);
        model.addAttribute("rebalancingIdeas", rebalancingIdeas);
        model.addAttribute("totalCurrentValue", portfolioItems1.stream().mapToDouble(PortfolioItem::getCurrentValue).sum());
        model.addAttribute("totalProfitLoss", portfolioItems1.stream().mapToDouble(PortfolioItem::getProfitLoss).sum());

        System.out.println("Portfolio Home Page Model Attributes: " + model);
        return "portfolio"; // Return the name of the Thymeleaf template
    }

    /**
     * This is the dedicated endpoint for your planning module to call.
     * It receives the actual investment values calculated by your planning module
     * and stores them in the session, then redirects to the main portfolio view.
     *
     * @param totalInvestment The total investment value determined by the planning module.
     * @param goldBuyValue The gold investment value determined by the planning module.
     * @param mutualFundsBuyValue The mutual funds investment value determined by the planning module.
     * @param shareMarketBuyValue The share market investment value determined by the planning module.
     * @param model The Spring Model object to pass data to the session.
     * @return Redirects to the main portfolio page (/) to display the updated data.
     */
    @GetMapping("/displayPortfolioFromPlan")
    public String displayPortfolioFromPlan(
            @RequestParam("totalInv") double totalInvestment,
            @RequestParam("goldVal") double goldBuyValue,
            @RequestParam("mfVal") double mutualFundsBuyValue,
            @RequestParam("smVal") double shareMarketBuyValue,
            Model model) {

        // Store the values received from the planning module into the session.
        // @SessionAttributes annotation ensures these are picked up by Spring.
        model.addAttribute("totalInvestment", totalInvestment);
        model.addAttribute("goldBuyValue", goldBuyValue);
        model.addAttribute("mutualFundsBuyValue", mutualFundsBuyValue);
        model.addAttribute("shareMarketBuyValue", shareMarketBuyValue);

        System.out.println("Received from Planning Module and stored in session:");
        System.out.println("Total: " + totalInvestment + ", Gold: " + goldBuyValue +
                           ", MF: " + mutualFundsBuyValue + ", SM: " + shareMarketBuyValue);

        // Redirect to the main portfolio page. The 'home' method will then use these
        // newly stored session values to render the portfolio and the pie chart.
        // Redirect to /view as that's your actual home page mapping
        return "redirect:/view";
    }

    /**
     * Endpoint to clear all session attributes managed by `@SessionAttributes`.
     * Useful for resetting the portfolio state.
     *
     * @param status The SessionStatus object to mark the session complete.
     * @return Redirects to the home page, which will then display an empty portfolio (as no values are in session).
     */
    @GetMapping("/clearSession")
    public String clearSession(SessionStatus status) {
        status.setComplete(); // Invalidates session attributes
        System.out.println("Session attributes cleared.");
        // Redirect to /view as that's your actual home page mapping
        return "redirect:/view";
    }
}